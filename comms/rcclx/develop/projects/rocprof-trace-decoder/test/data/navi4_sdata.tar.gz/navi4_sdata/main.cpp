/*
Copyright (c) 2015-2016 Advanced Micro Devices, Inc. All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
#include <assert.h>
#include <stdio.h>
#include <algorithm>
#include <stdlib.h>
#include <iostream>
#include "hip/hip_runtime.h"

#define HIP_ASSERT(x) { if((x)!=hipSuccess) abort(); }

__attribute_noinline__ __device__ float squared(float x)
{
    asm volatile("s_ttracedata_imm 7;");
    return x*x;
}

__attribute_noinline__ __device__ float rms(float x, float y)
{
    asm volatile("s_ttracedata;");
    asm volatile("s_nop 0; s_nop 1; s_nop 2;");
    return sqrtf(squared(x) + squared(y));
}

#define REGWIDE 16

__global__ void vectorops()
{
    int x = hipBlockDim_x * hipBlockIdx_x + hipThreadIdx_x;
    int y = hipBlockDim_y * hipBlockIdx_y + hipThreadIdx_y;

    __syncthreads();

    float z = rms(x, y);

    __syncthreads();

    float a[REGWIDE] = {0};

    #pragma unroll 8
    for (int i=0; i<128; i++)
    {
        #pragma unroll
        for (int j=0; j<REGWIDE; j++) a[j] = a[j] + 1;

        #pragma unroll
        for (int j=0; j<REGWIDE; j++)
            asm volatile("v_add_f32 %0, %1, %2" : "=v"(z) : "v"(z), "v"(a[j]));

        z = sqrtf(z);

        if (i%16 == 0) __syncthreads();
    }
}

int main()
{
    int num_simd = 64;
    hipLaunchKernelGGL(vectorops, num_simd/4, dim3(32*32), 0, 0);
    return 0;
}
